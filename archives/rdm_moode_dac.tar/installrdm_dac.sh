#!/bin/sh
cp rdm_config.ini /boot/moodecfg.ini
moodeutl -i
touch /boot/userconfig.txt
sed -i '/include userconfig.txt/d' /boot/config.txt
echo "include userconfig.txt" >> /boot/config.txt
tar -xvzf rdmdac.tar.gz -C /usr/local/bin/
chmod +xX /usr/local/bin/apessq2m
exit 0
