
#!/bin/sh
mkdir -p /usr/local/etc/
tar -xvzf rdmoled.tar.gz -C /usr/local/etc/
ln -s /usr/local/etc/raspdacminioled/rdmoled.sh /usr/local/bin/rdmoled
chmod +x /usr/local/bin/rdmoled
printf "[Unit]
Description=OLED Display Service
After=volumio.service
[Service]
WorkingDirectory=/usr/local/etc/raspdacminioled/
ExecStart=`which sudo` `which node` /usr/local/etc/raspdacminioled/index.js volumio
StandardOutput=null
KillSignal=SIGINT
Type=simple
User=root
[Install]
WantedBy=multi-user.target"> /etc/systemd/system/oled.service 
systemctl daemon-reload
systemctl enable oled	
systemctl restart oled	
	