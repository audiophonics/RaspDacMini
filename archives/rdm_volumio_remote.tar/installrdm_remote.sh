#!/bin/bash

# ---------------------------------------------------
# Install dependencies 
apt-get update -y
apt-get install --no-install-recommends -y lirc

# ---------------------------------------------------
# Enable gpio-ir driver to allow hardware interfacing
if ! grep -q "dtoverlay=gpio-ir,gpio_pin=4" "/boot/userconfig.txt"; then
    echo "dtoverlay=gpio-ir,gpio_pin=4"  >> /boot/userconfig.txt
fi

# ---------------------------------------------------
# push config
tar -xvzf rdmremote.tar.gz -C /etc/

# ---------------------------------------------------
# enable service

systemctl daemon-reload
systemctl enable lircd
systemctl restart lircd
systemctl enable irexec
systemctl restart irexec

exit 0
